---
name: Nocturne Verdant
colors:
  surface: '#101412'
  surface-dim: '#101412'
  surface-bright: '#353a37'
  surface-container-lowest: '#0a0f0c'
  surface-container-low: '#181d1a'
  surface-container: '#1c211e'
  surface-container-high: '#262b28'
  surface-container-highest: '#313632'
  on-surface: '#dfe4de'
  on-surface-variant: '#d7c3ae'
  inverse-surface: '#dfe4de'
  inverse-on-surface: '#2c322e'
  outline: '#9f8e7a'
  outline-variant: '#524434'
  surface-tint: '#ffb959'
  primary: '#ffb959'
  on-primary: '#462a00'
  primary-container: '#e89a1b'
  on-primary-container: '#593800'
  inverse-primary: '#845400'
  secondary: '#dabce8'
  on-secondary: '#3d274b'
  secondary-container: '#574065'
  on-secondary-container: '#ccaeda'
  tertiary: '#b5cdad'
  on-tertiary: '#21351e'
  tertiary-container: '#99b192'
  on-tertiary-container: '#2f442c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb6'
  primary-fixed-dim: '#ffb959'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#643f00'
  secondary-fixed: '#f4d9ff'
  secondary-fixed-dim: '#dabce8'
  on-secondary-fixed: '#271235'
  on-secondary-fixed-variant: '#553e63'
  tertiary-fixed: '#d1eac8'
  tertiary-fixed-dim: '#b5cdad'
  on-tertiary-fixed: '#0c200b'
  on-tertiary-fixed-variant: '#374c33'
  background: '#101412'
  on-background: '#dfe4de'
  surface-variant: '#313632'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0em
  headline-md:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 34px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style
The design system establishes an atmospheric, contemplative digital presence for author David Hamilton, directly translating the nocturnal, hillside world captured in the cover art of *Bois*. The aesthetic balances gritty literary realism with lyrical nocturnal introspection. It avoids sterile corporate minimalism and flashy contemporary gimmicks, instead leaning into tactile editorial prestige, low-key lighting, and rich shadowy environments punctuated by illuminated domestic windows.

The visual style blends **Editorial Prestige** with **Chiaroscuro Nocturne**:
- **Atmosphere & Tone:** Deep twilight canopies, muted foliage, earthy textures, and quiet interior warmth. It evokes the stillness of a hillside community at dusk, where human stories glow faintly against dense foliage and raw architecture.
- **Audience:** Avid readers of contemporary literary fiction, critics, festival programmers, acquisition editors, and literary prize committees seeking depth, place-specific storytelling, and nuanced narrative voices.
- **Emotional Response:** Intrigue, solemn beauty, grounded gravitas, and the intimate hush of evening storytelling under single-bulb lamplight.

## Colors
The palette is rooted in the hillside nocturne of the reference work: deep jungle greens, nocturnal charcoals, raw architectural tones, and sudden points of illumination.

- **Primary (`#E89A1B` - Lantern Ochre):** The glowing window panes and warm lamplight catching skin and wood. Reserved for critical focal points, primary interactive states, pull-quote highlights, and purchase actions.
- **Secondary (`#846A92` - Twilight Lavender):** Drawn from the protagonist's washed lilac shirt; provides an unexpected, poetic counterpoint to the organic greens. Used for metadata tags, literary genre pills, secondary links, and subtle decorative borders.
- **Tertiary (`#3A4F36` - Forest Canopy):** The dense foliage of the hillside. Serves as a grounding accent for secondary cards, surface washes, and muted badges.
- **Neutral (`#131815` - Midnight Verdant):** An ink-dark charcoal with an undertone of deep moss. Provides the foundation for canvas backgrounds and deep tonal staging.
- **Text & Contrast:** Primary text renders in parchment white (`#EDE8DE`), while secondary editorial notes use soft ash olive (`#9BA397`), ensuring effortless long-form reading without the stark glare of pure white on black.

## Typography
Typography is split purposefully between classical literary storytelling and contemporary utilitarian structure:

- **Headlines (Newsreader):** A variable serif with high optical charm. Evokes fine literary press publishing, hardbound dustjackets, and quiet gravitas. Headings use medium and light weights to keep forms delicate against dark backgrounds. Italic styles are utilized for excerpts, critical blurbs, and epigraphs.
- **Body & Functional UI (Plus Jakarta Sans):** A humanist, geometric sans-serif that remains crisp at small sizes. Used for reader blurbs, book synopses, tour dates, and navigation.
- **Hierarchy Rules:** Large editorial display headers never compete with button labels. All category tags, ISBN metadata, and publication dates employ `label-sm` or `label-md` in uppercase with deliberate tracking (`0.06em` to `0.08em`).

## Layout & Spacing
The layout follows a disciplined 12-column desktop grid with generous vertical pauses, referencing the layout margins of limited-edition publications.

- **Desktop (1024px+):** 12-column grid with a maximum content container of `1200px`. Asymmetrical columns prioritize book jacket displays (e.g., 5 columns for jacket art, 7 columns for synopsis and purchase pathways).
- **Tablet (768px - 1023px):** 8-column grid with `1.5rem` gutters. Content cascades naturally into clean split panes.
- **Mobile (< 768px):** 4-column grid with `1rem` gutters and `1.25rem` outer margins. Hero covers occupy full viewport widths with editorial overlays.
- **Vertical Rhythm:** Sections are separated by generous breathing room (`space-xl` and larger multiples) to honor literary pacing, allowing artwork and text excerpts room to linger.

## Elevation & Depth
Elevation mimics chiaroscuro environmental depth—layering surfaces like homes stepped across a dim hillside—rather than standard drop shadows.

- **Surface Tiers:**
  - *Base Canvas:* `#131815` (deep nocturnal forest green).
  - *Surface Level 1 (Panels & Cards):* `#1C2420` (slate-toned olive shadow).
  - *Surface Level 2 (Modals & Popovers):* `#25302A` (illuminated brush shade).
- **Ambient Glows:** In place of gray shadows, elevated elements and active interactive elements utilize an ambient lantern bleed: `0 8px 32px -4px rgba(232, 154, 27, 0.12)`.
- **Low-Contrast Framing:** Container edges are defined using fine, low-opacity strokes (`1px solid rgba(237, 232, 222, 0.08)`) instead of harsh divider borders, creating a cohesive, bookbound structure.

## Shapes
The shape language takes cues from trimmed archival book blocks and timber dwellings:

- **Soft Contours (`roundedness: 1`):** Base components, cards, and input fields use an understated `0.25rem` (4px) corner radius. This evokes cleanly trimmed paper stock and architectural wood slats rather than plastic app geometry.
- **Book Covers & Visual Assets:** Kept strictly crisp with `0px` radius, paired with a delicate inner inset stroke (`1px inset rgba(255, 255, 255, 0.1)`) to simulate physical hardcover cloth and binding edges.
- **Pills & Chips:** Limited to `0.5rem` (`rounded-lg`) to maintain a serious, structured editorial silhouette.

## Components

- **Buttons:**
  - *Primary Button:* Solid `#E89A1B` (Lantern Ochre) with ink-dark text (`#131815`), semi-bold weight, and a soft lantern aura on hover (`box-shadow: 0 0 16px rgba(232, 154, 27, 0.3)`).
  - *Secondary Button:* Ghost styling with a `1px` border of `rgba(237, 232, 222, 0.25)` and parchment text (`#EDE8DE`), transitioning to a subtle lilac tint (`#846A92`) on hover.
  - *Text Button / Editorial Link:* Underlined in delicate `rgba(232, 154, 27, 0.5)` with an italic serif transition.
- **Chips & Badges:**
  - Built for literary awards, genres, and event formats. Rendered in semi-transparent twilight lavender (`rgba(132, 106, 146, 0.15)`) with an `#846A92` hairline border and uppercase `label-sm` tracking.
- **Cards (Book Showcases & Essays):**
  - Dark slate olive backgrounds (`#1C2420`) with hairline outline definition. Card headers feature `Newsreader` italic titles. On hover, the container subtly lightens to `#222C27` with a low-intensity ochre warmth along the bottom border.
- **Inputs & Newsletter Capture:**
  - Recessed field styling using `#101412` background, inset hairline borders, and `Plus Jakarta Sans` placeholder text in `#9BA397`. Focus states illuminate the border in `#E89A1B` with no harsh outline rings.
- **Checkboxes & Radios:**
  - Subtle squared forms (`rounded: 2px`), bordered with `rgba(237, 232, 222, 0.3)`, filled with `#E89A1B` when selected, preserving the bookish print feel.
- **Editorial Pull Quotes:**
  - Large-format `Newsreader` italic with a vertical gutter rule tinted in Twilight Lavender (`#846A92`), paired with publication metadata in tracked `label-sm`.
- **Tour & Appearance List:**
  - Minimal horizontal rule dividers (`rgba(237, 232, 222, 0.08)`), date badges rendered in Lantern Ochre mono-spaced tabular numerals, venue titles in serif, and ticket links presented as discreet arrow glyphs.